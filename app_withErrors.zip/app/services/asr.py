# app/services/asr.py
# Stub: return text directly until you plug real Whisper streaming
def transcribe(audio_bytes: bytes) -> str:
    return "[Transcription stub] Please connect Whisper here."
